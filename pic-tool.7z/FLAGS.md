--no-clear flag for not clearning the screen (pic-tool.py)
-nc flag for not clearning the screen (pic-tool.py)
--no-art flag for not getting the ascii art(pic-tool.py)
-dm, -d, --dir-mode         Define Directory mode.
-sm, -s, --sin-mode         Define Single image mode.


OPTIONS in the tool

image compressor 

image resizer

image thumbnail maker

image file extension changer

image metadata extractor

image metadata remover