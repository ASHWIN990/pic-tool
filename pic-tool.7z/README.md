# pic-tool
### Author : ASHWINI SAHU
A image manipulation tool written in python ❤
